# DevOps Portfolio – Марина Фрунчак

## About Me


## Goals


## Tech Stack
- Linux, Git, Docker, Node.js, Python
- 

## Learning Roadmap


## Contacts
- Email:
- GitHub: 
