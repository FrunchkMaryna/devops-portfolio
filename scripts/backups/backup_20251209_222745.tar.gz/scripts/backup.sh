#!/usr/bin/env bash
set -euo pipefail

# Налаштування (змінити під себе)
SRC_DIR="${1:-/path/to/source}"   # можна передати як перший аргумент
DEST_DIR="${2:-./scripts/backups}"
KEEP=5
LOG_FILE="${DEST_DIR}/backup.log"

mkdir -p "$DEST_DIR"

timestamp="$(date +%Y%m%d_%H%M%S)"
archive_name="backup_${timestamp}.tar.gz"
archive_path="${DEST_DIR}/${archive_name}"

echo "[$(date +'%Y-%m-%d %H:%M:%S')] Starting backup of ${SRC_DIR} -> ${archive_path}" | tee -a "$LOG_FILE"

# Створити архів (виключаємо DEST_DIR, якщо він всередині SRC_DIR)
tar --exclude="$DEST_DIR" -czf "$archive_path" -C "$(dirname "$SRC_DIR")" "$(basename "$SRC_DIR")" \
  && echo "[$(date +'%Y-%m-%d %H:%M:%S')] Archive created: ${archive_name}" | tee -a "$LOG_FILE" \
  || { echo "[$(date +'%Y-%m-%d %H:%M:%S')] ERROR creating archive" | tee -a "$LOG_FILE"; exit 1; }

# Очистка старих резервних копій — зберігаємо тільки останні $KEEP (за часом)
cd "$DEST_DIR"
# список архівів за датою (новіші зверху), видалити всі після KEEP
mapfile -t files < <(ls -1t backup_*.tar.gz 2>/dev/null || true)
if (( ${#files[@]} > KEEP )); then
  for ((i=KEEP; i<${#files[@]}; i++)); do
    rm -f "${files[i]}" && echo "[$(date +'%Y-%m-%d %H:%M:%S')] Removed old backup: ${files[i]}" | tee -a "$LOG_FILE"
  done
fi

echo "[$(date +'%Y-%m-%d %H:%M:%S')] Backup finished" | tee -a "$LOG_FILE"
